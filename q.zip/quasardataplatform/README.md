
# Build

## Prepare the environment

* Trigger the HUDI build
  ```bash
  mvn clean install -DskipTests -DskipITs
  ```

* Copy the hoodie hadoop MR jar
  ```bash
  add jar hdfs://quickstart.cloudera/user/cloudera/jars/hoodie-hadoop-mr-bundle-0.4.5-SNAPSHOT.hive11.jar
  ```

* Create a Hive Table
  ```sql
  CREATE EXTERNAL TABLE huditable(`_row_key`  string,
  `_hoodie_commit_time` string,
  `_hoodie_commit_seqno` string,
   trade_date INT,
   bats INT)
  PARTITIONED BY (`datestr` string)
  ROW FORMAT SERDE
     'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
  STORED AS INPUTFORMAT
     'com.uber.hoodie.hadoop.HoodieInputFormat'
  OUTPUTFORMAT
     'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
  LOCATION
     'hdfs://quickstart.cloudera/user/cloudera/hudi-table/';
  ```

 ## Build Application Jar

 * Build the App Jar
   ```
   mvn clean package
   ```

 * Run the spark-submit command
   ```
   /usr/local/spark/bin/spark-submit --class com.macquarie.quasar.Main --master yarn --deploy-mode client /kabeer/code/quasardataplatform/target/quasardataplatform-0.1-SNAPSHOT-jar-with-dependencies.jar hdfs://quickstart.cloudera/user/cloudera/junk hdfs://quickstart.cloudera/user/cloudera/junk1
   ```

 * Other commands
   ```
   java -cp /usr/lib/hadoop/*:/usr/lib/hadoop/client/*:/usr/lib/hive/lib/log4j-1.2.16.jar:/usr/lib/hive/lib/hive-metastore-1.1.0-cdh5.13.0.jar:/usr/lib/hive/lib/hive-service-1.1.0-cdh5.13.0.jar:/usr/lib/hive/lib/hive-exec-1.1.0-cdh5.13.0.jar:/usr/lib/hive/lib/hive-service-1.1.0-cdh5.13.0.jar:/usr/lib/hive/lib/hive-jdbc-1.1.0-cdh5.13.0-standalone.jar:/usr/lib/hive/lib/hive-jdbc-standalone.jar:/opt/cloudera/parcels/CDH-5.13.0-1.cdh5.13.0.p0.29/lib/hadoop/share/hadoop/common/*:/opt/cloudera/parcels/CDH-5.13.0-1.cdh5.13.0.p0.29/lib/hadoop/share/hadoop/mapreduce/*:/opt/cloudera/parcels/CDH-5.13.0-1.cdh5.13.0.p0.29/lib/hadoop/share/hadoop/hdfs/*:/opt/cloudera/parcels/CDH-5.13.0-1.cdh5.13.0.p0.29/lib/hadoop/share/hadoop/common/lib/*:/opt/cloudera/parcels/CDH-5.13.0-1.cdh5.13.0.p0.29/lib/hadoop/share/hadoop/hdfs/lib/*:/opt/cloudera/parcels/CDH-5.13.0-1.cdh5.13.0.p0.29/lib/spark/conf/yarn-conf:/etc/hive/conf:/kabeer/code/apache/incubator-hudi/hoodie-hive/../packaging/hoodie-hive-bundle/target/hoodie-hive-bundle-0.4.5.jar com.uber.hoodie.hive.HiveSyncTool --base-path hdfs://quickstart.cloudera/user/cloudera/hudi-table/ --database default --table huditable --jdbc-url jdbc:hive2://quickstart.cloudera:10000 --user cloudera --pass cloudera
   ```