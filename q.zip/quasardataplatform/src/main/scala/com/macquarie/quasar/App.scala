package com.macquarie.quasar

import java.sql.Timestamp
import java.text.SimpleDateFormat

import com.uber.hoodie.common.model.{HoodieKey, HoodieRecord}
import com.uber.hoodie.common.util.HoodieAvroUtils
import com.uber.hoodie.config.HoodieWriteConfig
import com.uber.hoodie.DataSourceWriteOptions

import org.apache.avro.generic.{GenericData, GenericFixed, IndexedRecord}
import org.apache.avro.mapred.AvroWrapper
import org.apache.avro.Schema
import org.apache.avro.Schema.Type._

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path

import org.apache.log4j.LogManager

import org.apache.spark.SparkException
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._


/**
 * @author ${user.name}
 */
object Main extends App {

  val logger = LogManager.getLogger(getClass)

  logger.info("MAR Application Processing Started")

  if(args.length != 2) throw new Exception("JUNK")

  // Spark session
  val spark = SparkSession.builder().appName("argument")
    .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    .getOrCreate()

  // hdfs

  val hadoopConf = spark.sparkContext.hadoopConfiguration
  val hdfs = FileSystem.get(hadoopConf)

  val files = hdfs.listStatus(new Path(args(0)))
  val filesList : List[String] = files.map(_.getPath.toString).toList

  for (file <- filesList) {
    logger.info(s"file now is: $file")

    val fileName = file.split("/").last
    val result = hdfs.rename(new Path(file), new Path(args(1) + fileName))

  }

  case class HudiRecord(_row_key: String, trade_date: String, bats: java.lang.Integer)

  def rddRemoveDuplicates(inputDF: DataFrame) : RDD[String] = {

    inputDF.rdd // Retrieve RDD from the dataframe
      .map(_.mkString(",")) // Add a , separator
      .map(row => (row.split(",")(0), row)) // Split the row into rowkey vs row
      .reduceByKey((dup, dup1) => null) // Remove the duplicates by doing reduceByKey to null
      .filter(row => if (row._2 == null) false else true) // filter the rows having empty values to remove duplicates
      .values // we do not need the row key that was created. Pick up the values now

  }

  val schema = Encoders.product[HudiRecord].schema

  /* Read and cache the CSV file as this will be the base of all the DataFrames that will be generated */
  val inputDF = spark.read
    .option("header", "true")
    .schema(schema)
    .csv("hdfs://quickstart.cloudera/user/cloudera/input/input.csv")
    .toDF
    .na
    .drop("all", Seq("_row_key", "trade_date", "bats"))
    .cache()

  /* HUDI OPERATIONS */
  val rddWithoutDuplicates = rddRemoveDuplicates(inputDF)

  rddWithoutDuplicates.collect()

  // Convert RDD without duplicates to hoodie RDD
  val hoodieRDD: org.apache.spark.rdd.RDD[String] = rddWithoutDuplicates.map(row => convertToHoodieString(row))

  // convert hoodie RDD to dataframe
  val hoodieInsertDF = spark.read.json(hoodieRDD)

  // Save as hoodie dataset (copy on write)
  var writer = hoodieInsertDF.write.format("com.uber.hoodie") // specify the hoodie source
    .option("hoodie.insert.shuffle.parallelism",
    "2") // any hoodie client config can be passed like this
    .option("hoodie.upsert.shuffle.parallelism",
    "2") // full list in HoodieWriteConfig & its package
    .option(DataSourceWriteOptions.STORAGE_TYPE_OPT_KEY, "COPY_ON_WRITE") // Hoodie Table Type
    .option(DataSourceWriteOptions.OPERATION_OPT_KEY, "insert") // insert
    .option(DataSourceWriteOptions.RECORDKEY_FIELD_OPT_KEY, "_row_key") // This is the record key
    .option(DataSourceWriteOptions.PARTITIONPATH_FIELD_OPT_KEY, "partition") // this is the partition
    .option(DataSourceWriteOptions.PRECOMBINE_FIELD_OPT_KEY, "timestamp") // use to combine duplicate
    .option(HoodieWriteConfig.TABLE_NAME, "kabeer_test") // Used by hive sync and queries
    .option(DataSourceWriteOptions.PAYLOAD_CLASS_OPT_KEY, classOf[QuasarUpsertPayload].getName)
    .mode(SaveMode.Overwrite); // This will remove any existing data at path below, and create a

  writer.save("hdfs://quickstart.cloudera/user/cloudera/hudi-table/")

  val updateDF = spark.read
    .option("header", "true")
    .schema(schema)
    .csv("hdfs://quickstart.cloudera/user/cloudera/input/update.csv")
    .cache()

  val updateRDDWithoutDuplicates = rddRemoveDuplicates(updateDF)

  val updateHoodieRDD: org.apache.spark.rdd.RDD[String] =
    updateRDDWithoutDuplicates.map(row => convertToHoodieString(row))

  val updateJSONDF = spark.read.json(updateHoodieRDD)

  // Save as hoodie dataset (copy on write)
  writer = updateJSONDF.write.format("com.uber.hoodie") // specify the hoodie source
    .option("hoodie.insert.shuffle.parallelism",
    "2") // any hoodie client config can be passed like this
    .option("hoodie.upsert.shuffle.parallelism",
    "2") // full list in HoodieWriteConfig & its package
    .option(DataSourceWriteOptions.STORAGE_TYPE_OPT_KEY, "COPY_ON_WRITE") // Hoodie Table Type
    .option(DataSourceWriteOptions.RECORDKEY_FIELD_OPT_KEY,
    "_row_key") // This is the record key
    .option(DataSourceWriteOptions.PARTITIONPATH_FIELD_OPT_KEY,
    "partition") // this is the partition to place it into
    .option(DataSourceWriteOptions.PRECOMBINE_FIELD_OPT_KEY,
    "timestamp") // use to combine duplicate records in input/with disk val
    .option(HoodieWriteConfig.TABLE_NAME, "kabeer_test") // Used by hive sync and queries
    .option(DataSourceWriteOptions.PAYLOAD_CLASS_OPT_KEY, classOf[QuasarUpsertPayload].getName)
    .mode(
    SaveMode.Append); // This will remove any existing data at path below, and create a

  writer.save("hdfs://quickstart.cloudera/user/cloudera/hudi-table/")


  def convertToHoodieString(row: String) : String = {

    // val logger = LogManager.getLogger("mar.MARApp")

    val logger = LogManager.getLogger(getClass)

    logger.info("CONVERT TO HOODIE STRING")

    logger.info(s"row is: ${row}")

    val _row_key = row.split(",")(0).trim
    val trade_date = row.split(",")(1).trim

    val bats : java.lang.Integer =
      if(row.split(",")(2) != "null" && row.split(",")(2) != null)
        row.split(",")(2).trim.toInt
      else -1 // Retrieve Int from String

    val sdf = new SimpleDateFormat("yyyy-mm-dd")
    val tDate = sdf.format(sdf.parse(trade_date))

    val partitionPath = tDate.replace("-", "/")
    val key = new HoodieKey(_row_key, partitionPath)
    val hoodieRecord = new HoodieRecord[QuasarHoodiePayload](key,
      generateHudiRecords(key, _row_key, trade_date, bats))

    val opt = DataSourceTestUtils.convertToString(hoodieRecord)

    if (!opt.isPresent) throw new RuntimeException("bad error")

    opt.get()

  }


  def generateHudiRecords(key: HoodieKey, _row_key: String, trade_date: String, bats: java.lang.Integer)
  : QuasarHoodiePayload = {

    val logger = LogManager.getLogger(getClass)

    val KUDI_EXAMPLE_SCHEMA = "{\"type\": \"record\"," + "\"name\": \"hudirec\"," + "\"fields\": [ " +
      "{\"name\": \"timestamp\",  \"type\": \"double\"}," +
      "{\"name\": \"_row_key\",   \"type\": \"string\"}," +
      "{\"name\": \"trade_date\", \"type\": \"string\"}," +
      "{\"name\": \"bats\",       \"type\": \"int\"}]}";

    val avroSchema = HoodieAvroUtils.addMetadataFields(new Schema.Parser().parse(KUDI_EXAMPLE_SCHEMA))

    logger.info(s"avroschema created is: $avroSchema")

    val rec = new GenericData.Record(avroSchema)

    logger.info(s"trade_date is: ${trade_date}, _row_key is: ${_row_key}")

    rec.put("timestamp", 0.0)
    rec.put("_row_key", _row_key)
    rec.put("trade_date", trade_date)
    rec.put("bats", bats)

    HoodieAvroUtils.addCommitMetadataToRecord(rec, new Timestamp(System.currentTimeMillis()).toString, "-1")

    new QuasarHoodiePayload(rec.toString(), key.getRecordKey(), key.getPartitionPath(), KUDI_EXAMPLE_SCHEMA)

  }

}
