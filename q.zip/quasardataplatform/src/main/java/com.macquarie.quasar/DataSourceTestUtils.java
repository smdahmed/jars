
package com.macquarie.quasar;

import com.uber.hoodie.common.model.HoodieRecord;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Test utils for data source tests.
 */
public class DataSourceTestUtils {

  public static Optional<String> convertToString(HoodieRecord record) {
    try {
      String str = ((QuasarHoodiePayload) record.getData()).getJsonData();
      str = "{" + str.substring(str.indexOf("\"timestamp\":"));
      return Optional.of(str.replaceAll("}",
        ", \"partition\": \"" + record.getPartitionPath() + "\"}"));
    } catch (IOException e) {
      return Optional.empty();
    }
  }

  public static List<String> convertToStringList(List<HoodieRecord> records) {
    return records.stream().map(hr -> convertToString(hr)).filter(os -> os.isPresent())
      .map(os -> os.get()).collect(Collectors.toList());
  }
}
